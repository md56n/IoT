TensorFlow community examples and notebooks
